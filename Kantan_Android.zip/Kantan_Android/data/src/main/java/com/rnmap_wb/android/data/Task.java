package com.rnmap_wb.android.data;

/**
 * 任务
 */
public class Task {



    public String id;
    public String dir_id;
    public String name;
    public String created;
    public String kml;
    public String kml_name;
    public String memo;
    public String user_id;
    public String user_name;
    public String dir_name;

}
