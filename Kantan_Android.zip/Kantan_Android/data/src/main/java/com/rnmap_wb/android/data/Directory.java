package com.rnmap_wb.android.data;

import java.util.List;

public class Directory {

    public String dir_id;
    public  String dir_name;
    public List<Task> list;
}
