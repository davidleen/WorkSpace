package com.rnmap_wb.android.data;

public class VersionData {

    public  String  type;
    public  String  version;
    public  int version_num;
    public  String  message;
    public  String  down_url;
    public  String  app_name;
    public  String  created;
}
