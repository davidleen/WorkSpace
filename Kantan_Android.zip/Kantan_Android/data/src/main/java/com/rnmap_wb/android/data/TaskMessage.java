package com.rnmap_wb.android.data;

public class TaskMessage {

    public String id;
    public String title;
    public String content;
    public String created;
   public  Task task;


    /**
     * 本地数据
     */
    public boolean read;
}
