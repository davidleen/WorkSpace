package com.rnmap_wb.android.data;

public class UploadFileResult {
    public String httpPath;
    public String path;
}
