package com.rnmap_wb.android.data;

public class ProjectReply {

    public String memo;
    public String picture;
    public String id;
    public String createTime;
    public String user_id;
    public String user_name;
}
