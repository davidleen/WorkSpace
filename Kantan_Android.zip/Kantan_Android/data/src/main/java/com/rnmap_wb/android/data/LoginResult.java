package com.rnmap_wb.android.data;

public class LoginResult {

  public   String id;
  public   String name;
  public   String email;
  public   String phone;
  public   String login_date;
  public   String token;
}
