package com.rnmap_wb.android.data;

public class VerifyCodeResult {
    public String code;
    public String email;
}
