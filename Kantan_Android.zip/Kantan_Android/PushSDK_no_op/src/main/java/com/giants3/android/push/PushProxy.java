package com.giants3.android.push;

import android.content.Context;

import com.giants3.android.api.push.RegisterCallback;

/**
 * Created by davidleen29 on 2018/3/31.
 */


public class PushProxy {

    public static  void config(Context context, final RegisterCallback callback){}

    public static void onAppStart( )
    {

    }
}
