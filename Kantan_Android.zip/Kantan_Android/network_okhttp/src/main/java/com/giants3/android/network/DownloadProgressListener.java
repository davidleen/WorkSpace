package com.giants3.android.network;

public interface DownloadProgressListener {

    public void onProgressUpdate(long current,long totalLength);
}
