package com.giants3.android.reader.domain;

public abstract class DefaultUseCaseHandler<T   > implements UseCaseHandler<T>  {
    @Override
    public void onCompleted() {

    }
}
