package com.giants3.android.network;

public interface  ProgressListener {

    public void onProgressUpdate(long current,long totalLength);
}
