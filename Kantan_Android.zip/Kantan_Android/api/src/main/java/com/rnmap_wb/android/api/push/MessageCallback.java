package com.rnmap_wb.android.api.push;

/**
 * Created by davidleen29 on 2018/6/24.
 */

public interface MessageCallback {

     void onMessageReceived(String message);
}
