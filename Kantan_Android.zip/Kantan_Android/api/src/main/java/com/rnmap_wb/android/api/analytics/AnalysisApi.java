package com.rnmap_wb.android.api.analytics;

import android.content.Context;

/**
 * Created by davidleen29 on 2018/3/31.
 */

public interface AnalysisApi {


    public void onResume(Context context);


    public void onPause(Context context);


}
