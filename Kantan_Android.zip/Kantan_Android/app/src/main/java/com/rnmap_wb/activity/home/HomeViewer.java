package com.rnmap_wb.activity.home;

import com.giants3.android.mvp.Viewer;

public interface HomeViewer  extends Viewer {
}
