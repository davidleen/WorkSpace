package com.rnmap_wb.entity;

import java.util.List;

public class PostElements {

    public String taskId;
    public List<MapElement> flags;
    public String feedback;
}
