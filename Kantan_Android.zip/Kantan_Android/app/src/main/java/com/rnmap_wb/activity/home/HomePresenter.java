package com.rnmap_wb.activity.home;

import com.giants3.android.mvp.Presenter;

public interface HomePresenter extends Presenter<HomeViewer> {
}
