package com.rnmap_wb.activity.mapwork.map;

import org.osmdroid.views.overlay.OverlayWithIW;

public interface OnMapItemLongClickListener {

    void  onLongClick(OverlayWithIW  iw);
}
