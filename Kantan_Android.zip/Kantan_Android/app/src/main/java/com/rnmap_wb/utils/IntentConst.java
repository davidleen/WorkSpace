package com.rnmap_wb.utils;

public class IntentConst {

    public static final String KEY_EMAIL="KEY_EMAIL";
    public static final String KEY_PASSWORD="KEY_PASSWORD";
    public static final String KEY_TASK_ID = "TASK_ID";
    public static final String KEY_TASK_DETAIL = "TASK_DETAIL";
    public static final String PARAM_KML_PATH = "PARAM_KML_PATH";
    public static final String KEY_LATLNG = "KEY_LATLNG";
    public static final String KEY_MAP_ELEMENT = "KEY_MAP_ELEMENT";
}
