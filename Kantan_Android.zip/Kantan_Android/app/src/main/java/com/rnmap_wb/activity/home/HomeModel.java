package com.rnmap_wb.activity.home;

import com.giants3.android.mvp.Model;

public interface HomeModel extends Model {
}
